import "./c3runtime.js";
import "./objRefTable.js";
import "./project/main.js";
import "./project/scriptsInEvents.js";
